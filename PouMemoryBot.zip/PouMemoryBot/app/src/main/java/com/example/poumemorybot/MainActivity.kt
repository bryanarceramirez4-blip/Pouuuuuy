package com.example.poumemorybot

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity

class MainActivity : android.app.Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Pou Memory Bot"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "1. Activa el servicio de accesibilidad.\n2. Abre Pou.\n3. Regresa al bot y pulsa INICIAR."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 30)
        }

        val settings = Button(this).apply {
            text = "Abrir Accesibilidad"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val start = Button(this).apply {
            text = "INICIAR / DETENER"
            setOnClickListener {
                PouAccessibilityService.instance?.toggleBot()
                updateStatus()
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(settings)
        root.addView(start)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val service = PouAccessibilityService.instance
        status.text = when {
            service == null -> "Servicio no conectado. Activa Pou Memory Bot en Accesibilidad."
            service.isRunning -> "BOT ACTIVO\nDetectando bocas..."
            else -> "Servicio conectado. Pulsa INICIAR / DETENER."
        }
    }
}
