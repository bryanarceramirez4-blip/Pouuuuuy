package com.example.poumemorybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class PouAccessibilityService : AccessibilityService() {

    companion object {
        var instance: PouAccessibilityService? = null
            private set

        // Ajustes principales
        const val SCAN_INTERVAL_MS = 100L
        const val SAME_OPEN_DEBOUNCE_MS = 180L
        const val NEXT_EVENT_MIN_GAP_MS = 250L
        const val SEQUENCE_TIMEOUT_MS = 5_000L
        const val PLAY_INTERVAL_MS = 320L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var screenshotBusy = false
    private var lastDetectedPou = -1
    private var lastDetectionTime = 0L
    private var lastAnyMouthTime = 0L
    private val sequence = mutableListOf<Int>()

    val isRunning: Boolean get() = running.get()

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (!running.get()) return
            requestScreenshot()
            handler.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stopBot()
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun toggleBot() {
        if (running.get()) stopBot() else startBot()
    }

    private fun startBot() {
        if (!running.compareAndSet(false, true)) return
        sequence.clear()
        lastDetectedPou = -1
        lastDetectionTime = 0L
        lastAnyMouthTime = System.currentTimeMillis()
        handler.removeCallbacks(scanRunnable)
        handler.post(scanRunnable)
    }

    private fun stopBot() {
        running.set(false)
        handler.removeCallbacksAndMessages(null)
        screenshotBusy = false
        sequence.clear()
    }

    private fun requestScreenshot() {
        if (!running.get() || screenshotBusy) return
        screenshotBusy = true

        takeScreenshot(
            /* displayId = */ 0,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    try {
                        val bitmap = screenshot.bitmap
                        processFrame(bitmap)
                        bitmap.recycle()
                    } finally {
                        screenshotBusy = false
                    }
                }

                override fun onFailure(errorCode: Int) {
                    screenshotBusy = false
                }
            }
        )
    }

    private fun processFrame(bitmap: Bitmap) {
        if (!running.get()) return

        val now = System.currentTimeMillis()
        val pou = detectOpenMouth(bitmap)

        if (pou >= 0) {
            val isNewEvent = pou != lastDetectedPou || now - lastDetectionTime >= SAME_OPEN_DEBOUNCE_MS
            if (isNewEvent && now - lastDetectionTime >= NEXT_EVENT_MIN_GAP_MS) {
                sequence.add(pou)
                lastDetectedPou = pou
                lastDetectionTime = now
                lastAnyMouthTime = now
            }
        } else {
            // Permite detectar de nuevo al mismo Pou después de cerrar la boca.
            lastDetectedPou = -1
        }

        if (sequence.isNotEmpty() && now - lastAnyMouthTime >= SEQUENCE_TIMEOUT_MS) {
            val copy = sequence.toList()
            sequence.clear()
            lastDetectedPou = -1
            playSequence(copy)
        }
    }

    /**
     * Detecta el marrón oscuro de la boca abierta.
     * Las coordenadas son proporcionales a la pantalla del video de referencia (1080x1810).
     * Si la versión de Pou mueve los personajes, modifica MOUTH_BOXES_NORMALIZED.
     */
    private fun detectOpenMouth(bitmap: Bitmap): Int {
        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()

        for (i in MOUTH_BOXES_NORMALIZED.indices) {
            val b = MOUTH_BOXES_NORMALIZED[i]
            val left = (b[0] * w).toInt().coerceIn(0, bitmap.width - 1)
            val top = (b[1] * h).toInt().coerceIn(0, bitmap.height - 1)
            val right = (b[2] * w).toInt().coerceIn(left + 1, bitmap.width)
            val bottom = (b[3] * h).toInt().coerceIn(top + 1, bitmap.height)

            var darkBrown = 0
            var darkPixels = 0
            val step = 3

            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val c = bitmap.getPixel(x, y)
                    val r = Color.red(c)
                    val g = Color.green(c)
                    val bl = Color.blue(c)

                    // Boca abierta: marrón oscuro; evita contar la línea negra de la boca cerrada.
                    if (r < 120 && g < 80 && bl < 90 && r > g + 12) {
                        darkBrown++
                    }
                    if (r < 80 && g < 80 && bl < 80) darkPixels++
                    x += step
                }
                y += step
            }

            // Umbral relativo: la boca abierta ocupa bastante más área que una línea cerrada.
            if (darkBrown >= 18 && darkBrown > darkPixels * 0.45) return i
        }
        return -1
    }

    private fun playSequence(seq: List<Int>) {
        if (!running.get() || seq.isEmpty()) return

        var delay = 250L
        seq.forEach { pou ->
            handler.postDelayed({
                if (running.get()) performPouTap(pou)
            }, delay)
            delay += PLAY_INTERVAL_MS
        }
    }

    private fun performPouTap(index: Int) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val p = TOUCH_POINTS_NORMALIZED[index]
        val x = p[0] * w
        val y = p[1] * h

        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
            .build()

        dispatchGesture(gesture, null, null)
    }

    // Orden: 0 = arriba izquierda, 1 = arriba derecha,
    //        2 = abajo izquierda, 3 = abajo derecha.
    private val TOUCH_POINTS_NORMALIZED = arrayOf(
        floatArrayOf(0.25f, 0.40f),
        floatArrayOf(0.67f, 0.40f),
        floatArrayOf(0.25f, 0.66f),
        floatArrayOf(0.67f, 0.66f)
    )

    // Cajas alrededor de las bocas observadas en el video 1080x1810.
    // Formato: left, top, right, bottom, todo normalizado 0..1.
    private val MOUTH_BOXES_NORMALIZED = arrayOf(
        floatArrayOf(0.17f, 0.375f, 0.32f, 0.445f),
        floatArrayOf(0.59f, 0.375f, 0.75f, 0.445f),
        floatArrayOf(0.17f, 0.615f, 0.32f, 0.685f),
        floatArrayOf(0.59f, 0.615f, 0.75f, 0.685f)
    )
}
