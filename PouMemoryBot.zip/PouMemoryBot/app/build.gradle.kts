plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.poumemorybot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.poumemorybot"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
